create
    definer = root@localhost procedure User_imgUpdate(IN Uaccount char(12), IN Uimgurl varchar(100), OUT flag int)
begin
	update Users set Users.Uimgurl = Uimgurl where Users.Uaccount = Uaccount;
    set flag = 1;
end;

