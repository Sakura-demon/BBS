create
    definer = root@localhost procedure User_img(IN Uaccount int)
begin
	select Uimgurl from Users where Users.Uaccount = Uaccount;
end;

