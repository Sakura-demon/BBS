create
    definer = root@localhost procedure User_pastBackDelete(IN Bid int, OUT flag int)
begin
	delete from Back where Back.Bid = Bid;
    set flag = 1;
end;

