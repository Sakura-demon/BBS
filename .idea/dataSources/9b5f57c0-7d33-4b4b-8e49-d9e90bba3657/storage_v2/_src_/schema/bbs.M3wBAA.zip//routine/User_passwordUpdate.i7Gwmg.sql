create
    definer = root@localhost procedure User_passwordUpdate(IN Uaccount int, IN Upassword varchar(20), OUT flag int)
begin
	update Users set Users.Upassword = Upassword where Users.Uaccount = Uaccount;
    set flag = 1;
end;

