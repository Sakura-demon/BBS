create
    definer = root@localhost procedure Main_Publish(IN Mtitle varchar(100), IN Mmessage varchar(1000), IN Uaccount int,
                                                    OUT flag int)
begin
	insert into Message(Uaccount,Mtitle,Mtime,Mmessage) values(Uaccount,Mtitle,curdate(),Mmessage);
    set flag = 1;
end;

