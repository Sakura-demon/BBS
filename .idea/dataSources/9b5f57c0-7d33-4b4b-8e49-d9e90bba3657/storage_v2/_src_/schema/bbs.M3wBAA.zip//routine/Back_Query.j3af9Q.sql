create
    definer = root@localhost procedure Back_Query(IN Mid int)
begin
	select Bid,Uname,Uimgurl,Btime,Bmessage from Back
    join Users on Back.Uaccount = Users.Uaccount
    where Back.Mid = Mid;
end;

