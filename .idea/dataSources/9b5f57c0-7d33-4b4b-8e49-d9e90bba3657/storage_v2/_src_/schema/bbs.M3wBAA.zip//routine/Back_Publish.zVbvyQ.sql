create
    definer = root@localhost procedure Back_Publish(IN Mid int, IN Uaccount int, IN Bmessage varchar(1000), OUT flag int)
begin
	insert into back(Mid,Uaccount, Btime, Bmessage) values(Mid,Uaccount,curdate(),Bmessage);
    set flag = 1;
end;

