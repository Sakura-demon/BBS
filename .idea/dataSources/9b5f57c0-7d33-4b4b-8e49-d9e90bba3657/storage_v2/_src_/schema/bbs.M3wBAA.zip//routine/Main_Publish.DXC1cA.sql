create
    definer = root@localhost procedure Main_Publish(IN Mtitle varchar(100), IN Mmessage varchar(1000), IN Uaccount int,
                                                    IN Mhtmlurl varchar(100), OUT flag int)
begin
	insert into Message(Uaccount,Mtitle,Mtime,Mmessage,Mhtmlurl) values(Uaccount,Mtitle,curdate(),Mmessage,Mhtmlurl);
    set flag = 1;
end;

