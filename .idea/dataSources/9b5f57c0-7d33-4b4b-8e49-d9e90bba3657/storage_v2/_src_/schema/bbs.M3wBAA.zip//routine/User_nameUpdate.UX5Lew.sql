create
    definer = root@localhost procedure User_nameUpdate(IN Uaccount char(12), IN Uname varchar(20), OUT flag int)
begin
	update Users set Users.Uname = Uname where Users.Uaccount = Uaccount;
    set flag = 1;
end;

