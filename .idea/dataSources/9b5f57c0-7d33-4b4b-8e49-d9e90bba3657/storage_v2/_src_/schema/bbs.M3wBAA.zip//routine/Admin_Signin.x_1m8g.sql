create
    definer = root@localhost procedure Admin_Signin(IN Apassword char(12), OUT flag int)
begin
	if exists(select * from Admin where Admin.Apassword = Apassword)
		then set flag = 1;
	else
		set flag = 0;
	end if;
end;

