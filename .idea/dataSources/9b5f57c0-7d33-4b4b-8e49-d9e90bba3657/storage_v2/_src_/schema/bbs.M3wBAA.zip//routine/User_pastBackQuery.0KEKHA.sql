create
    definer = root@localhost procedure User_pastBackQuery(IN Uaccount char(12))
begin
	select Message.Mid,Uname,Uimgurl,Mtitle,Mtime,Bid,Bmessage,Btime from Users 
    join Message on Message.Uaccount = Users.Uaccount
    join Back on Back.Mid = Message.Mid
    where Users.Uaccount = Uaccount;
end;

