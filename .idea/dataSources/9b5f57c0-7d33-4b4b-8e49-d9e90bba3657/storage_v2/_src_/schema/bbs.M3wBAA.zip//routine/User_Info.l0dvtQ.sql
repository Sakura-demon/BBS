create
    definer = root@localhost procedure User_Info(IN Uaccount char(12))
begin
	select Uname,Uimgurl from Users where Users.Uaccount = Uaccount;
end;

