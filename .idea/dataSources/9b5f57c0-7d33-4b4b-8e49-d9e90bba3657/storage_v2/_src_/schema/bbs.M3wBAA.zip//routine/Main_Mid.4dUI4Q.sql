create
    definer = root@localhost procedure Main_Mid(IN Mid int)
begin
	select Mhtmlurl from Message where Message.Mid = Mid;
end;

