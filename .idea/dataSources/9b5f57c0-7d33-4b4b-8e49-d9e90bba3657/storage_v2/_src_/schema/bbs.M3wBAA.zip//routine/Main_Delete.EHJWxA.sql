create
    definer = root@localhost procedure Main_Delete(IN Mid int, OUT flag int)
begin
	delete from Back where Back.Mid = Mid;
	delete from Message where Message.Mid = Mid;
    set flag = 1;
end;

