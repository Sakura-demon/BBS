create
    definer = root@localhost procedure User_img(IN Uaccount char(12))
begin
	select Uimgurl from Users where Users.Uaccount = Uaccount;
end;

