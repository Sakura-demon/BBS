create
    definer = root@localhost procedure User_Info(IN Uaccount int)
begin
	select Uname,Uimgurl from Users where Users.Uaccount = Uaccount;
end;

