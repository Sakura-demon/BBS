create
    definer = root@localhost procedure Message_Query(IN Mid int)
begin
	select Mtitle,Mtime,Uimgurl,Uname,Mmessage from Message
    join Users on Message.Uaccount = Users.Uaccount
    where Message.Mid = Mid;
end;

