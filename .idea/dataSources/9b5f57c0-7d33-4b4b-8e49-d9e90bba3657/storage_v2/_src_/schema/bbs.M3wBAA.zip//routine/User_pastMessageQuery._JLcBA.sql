create
    definer = root@localhost procedure User_pastMessageQuery(IN Uaccount char(12))
begin
	select Mid,Uname,Uimgurl,Mtitle,Mtime from Users 
    join Message on Message.Uaccount = Users.Uaccount
    where Users.Uaccount = Uaccount;
end;

