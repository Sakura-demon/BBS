create
    definer = root@localhost procedure User_Signup(IN Uname char(12), IN Upassword varchar(20), OUT flag int)
begin
	if exists(select * from Users where Users.Uname = Uname and Users.Upassword = Upassword)
		then set flag = 0;
	else
		insert into users(Uname,Upassword) values(Uname,Upassword);
		set flag = 1;
        select Uaccount from Users where Users.Uname = Uname and Users.Upassword = Upassword;
	end if;
end;

